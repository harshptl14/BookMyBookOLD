import 'package:bookmybook/app_screens/recentadd.dart';
import 'package:bookmybook/app_screens/test.dart';
import 'package:flutter/material.dart';

import 'first_screen.dart';

class Categories extends StatefulWidget {
  @override
  _CategoriesState createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  Icon searchIcon = new Icon(Icons.search);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          primarySwatch: Colors.deepPurple,
          appBarTheme: AppBarTheme(
            brightness: Brightness.light,
            elevation: 5,
            color: ThemeData.light().canvasColor,
          )),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          centerTitle: false,
          title: Text(
            "Categories",
            style: TextStyle(
              fontSize: 22,
              color: Colors.black,
              fontFamily: 'Montserrat',
              fontWeight: FontWeight.bold,

              // fontWeight: FontWeight.bold,
            ),
          ),
          iconTheme: new IconThemeData(color: Colors.black),
          actions: <Widget>[
            IconButton(
                icon: searchIcon,
                color: Colors.black,
                onPressed: () {
                  heroTag:
                  "search";
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Test()));
                }),
          ],
          backgroundColor: Colors.white,
          leading: IconButton(
            color: Colors.black,
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => element()));
            },
            icon: Icon(Icons.arrow_back),
          ),
        ),
        body: ListView(children: <Widget>[
          SizedBox(height: 20.0),
          Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Column(children: <Widget>[
                   departments("depimages/cedep.jpg", 'Computer'),
                   departments('depimages/civildep.PNG', 'Civil'),
                   departments('depimages/itdep.PNG', 'IT'),
                   SizedBox(height: 80.0)

                ],),

                Column(children: <Widget>[

                   departments('depimages/ecdep.PNG', 'Ec'),
                   departments('depimages/mechdep.PNG', 'Mechanical'),
                   departments('depimages/mechdept1.PNG', 'AutoMobile'),
                   SizedBox(height: 25.0)

                ],)
               
              ])
        ]),
      ),
    );
  }

  Widget departments(String imgpath, String depname) {
    return Padding(
      padding: EdgeInsets.all(10.0),
      child: Container(
        height: 200.0,
        width: (MediaQuery.of(context).size.width / 2) - 20.0,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  spreadRadius: 2.0,
                  blurRadius: 2.0)
            ]),
        child: Column(
          children: <Widget>[
            Stack(children: <Widget>[
              Container(
                height: 125.0,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10.0),
                        topRight: Radius.circular(10.0)),
                    image: DecorationImage(
                        image: AssetImage(imgpath), fit: BoxFit.fitHeight)),
              )
            ]),

            Container(padding: EdgeInsets.only(top:25),
            child: 
            Text(depname, textAlign: TextAlign.center, style: TextStyle(color: Colors.black,
            fontSize: 14.0,
            fontFamily: 'Montserrat'),),)

          ],
        ),
      ),
    );
  }
}
