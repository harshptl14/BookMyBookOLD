import 'package:bookmybook/app_screens/first_screen.dart';
import 'package:bookmybook/app_screens/test.dart';
import 'package:flutter/material.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white10,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.white,
        leading: IconButton(
          color: Colors.black,
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => element()));
          },
          icon: Icon(Icons.arrow_back),
        ),
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.settings),
              color: Colors.black,
              onPressed: () {
                heroTag:
                "search";
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Test()));
              }),
        ],
      ),
      body: ListView(
        shrinkWrap: true,
        children: <Widget>[
          Stack(children: <Widget>[
            Container(

              decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.grey, blurRadius: 3.0),
                  ]),
              alignment: Alignment(0.0, -0.50),
              height: 200,
              child: Text(
                'Profile',
                style: TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: 20.0,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(25.0, 150.0, 25.0, 0.0),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20.0),
                  boxShadow: [
                    BoxShadow(color: Colors.grey, blurRadius: 1.0),
                  ]),
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Stack(children: <Widget>[
                      Container(
                          margin: EdgeInsets.fromLTRB(25.0, 25.0, 50.0, 25.0),
                          child: FlutterLogo(
                            colors: Colors.deepPurple,
                            size: 50,
                          )),
                      SizedBox(width: 100.0),
                      Container(
                        margin: EdgeInsets.fromLTRB(100.0, 35.0, 25.0, 25.0),
                        child: Text(
                          'Test User',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      )
                    ])
                  ]),
            ),
            Container(
              height: 340,
              margin: EdgeInsets.fromLTRB(25.0, 280.0, 25.0, 0.0),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20.0),
                  boxShadow: [
                    BoxShadow(color: Colors.grey, blurRadius: 1.0),
                  ]),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Stack(children: <Widget>[
                      Container(
                        alignment: Alignment.center,
                        color: Colors.white,
                        height: 70,
                        margin: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
                        child: ListTile(
                          leading: Icon(Icons.email),
                          title: Text('testuser@gmail.com',
                              style: TextStyle(
                                fontSize: 22,
                                fontFamily: 'Montserrat',
                              )),
                        ),
                      ),

                      Container(
                        alignment: Alignment.center,
                        color: Colors.white,
                        height: 70,
                        margin: EdgeInsets.fromLTRB(10.0, 70.0, 10.0, 0.0),
                        child: ListTile(
                          leading: Icon(Icons.phone),
                          title: Text('9002525252',
                              style: TextStyle(
                                fontSize: 22,
                                fontFamily: 'Montserrat',
                              )),
                        ),
                      ),

                      Container(
                        alignment: Alignment.center,
                        color: Colors.white,
                        height: 70,
                        margin: EdgeInsets.fromLTRB(10.0, 130.0, 10.0, 0.0),
                        child: ListTile(
                          leading: Icon(Icons.lock),
                          title: Text('**********',
                              style: TextStyle(
                                fontSize: 22,
                                fontFamily: 'Montserrat',
                              )),
                        ),
                      ),
                    ])
                  ]),
            ),
          ])
        ],
      ),
    );
  }
}
