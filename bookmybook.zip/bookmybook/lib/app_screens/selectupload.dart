// import 'package:bookmybook/app_screens/test.dart';
// import 'package:flutter/material.dart';
// import 'first_screen.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';

// class SelectDep extends StatefulWidget {
//   @override
//   _AddProductState createState() => _AddProductState();
// }

// class _AddProductState extends State<SelectDep> {
//   Icon searchIcon = new Icon(Icons.search);

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       theme: ThemeData(
//           primarySwatch: Colors.deepPurple,
//           appBarTheme: AppBarTheme(
//             brightness: Brightness.light,
//             elevation: 5,
//             color: ThemeData.light().canvasColor,
//           )),
//       debugShowCheckedModeBanner: false,
//       home: Scaffold(
//         appBar: AppBar(
//           centerTitle: false,
//           title: Text(
//             "Categories",
//             style: TextStyle(
//               fontSize: 22,
//               color: Colors.black,
//               fontFamily: 'Montserrat',
//               fontWeight: FontWeight.bold,

//               // fontWeight: FontWeight.bold,
//             ),
//           ),
//           iconTheme: new IconThemeData(color: Colors.black),
//           actions: <Widget>[
//             IconButton(
//                 icon: searchIcon,
//                 color: Colors.black,
//                 onPressed: () {
//                   heroTag:
//                   "search";
//                   Navigator.push(
//                       context, MaterialPageRoute(builder: (context) => Test()));
//                 }),
//           ],
//           backgroundColor: Colors.white,
//           leading: IconButton(
//             color: Colors.black,
//             onPressed: () {
//               Navigator.push(
//                   context, MaterialPageRoute(builder: (context) => element()));
//             },
//             icon: Icon(Icons.arrow_back),
//           ),
//         ),

//       //   body: Container(
//       //      ListView(
//       //     children: <Widget>[
//       //       ListTile(
//       //         leading: Icon(Icons.add),
//       //         title: Text("Computer"),
//       //         onTap: () {
//       //           Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduct()));
//       //         },
//       //       ),
//       //       Divider(),
//       //       ListTile(
//       //         leading: Icon(Icons.change_history),
//       //         title: Text("Mechanical"),
//       //         onTap: () {
//       //            Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduct()));
//       //         },
//       //       ),
//       //       Divider(),
//       //       ListTile(
//       //         leading: Icon(Icons.add_circle),
//       //         title: Text("Electrical"),
//       //         onTap: () {
//       //            Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduct()));
//       //         },
//       //       ),
//       //       Divider(),
//       //       ListTile(
//       //         leading: Icon(Icons.category),
//       //         title: Text("Civil"),
//       //         onTap: () {
//       //            Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduct()));
//       //         },
//       //       ),
//       //       Divider(),
//       //       ListTile(
//       //         leading: Icon(Icons.add_circle_outline),
//       //         title: Text("Electrical"),
//       //         onTap: () {

//       //            Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduct()));
               
//       //         },
//       //       ),
//       //       Divider(),
//       //       ListTile(
//       //         leading: Icon(Icons.library_books),
//       //         title: Text("EC"),
//       //         onTap: () {

//       //            Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduct()));

//       //         },
//       //       ),
//       //       Divider(),
//       //     ],
//       //   ),
//       // )
//       ),
//     );
//   }
// }

// class ListPage extends StatefulWidget {
//   @override
//   _ListPageState createState() => _ListPageState();
// }

// class _ListPageState extends State<ListPage> {

//   Future getPoasts() async {
//     var firestore = Firestore.instance;

//     QuerySnapshot qn = await firestore.collection("department").getDocuments();

//     return qn.documents;
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       child: FutureBuilder
//       (
//         future: getPoasts(),

//         builder: (_, snapshot){

//       if(snapshot.connectionState == ConnectionState.waiting){
//         return Center(
//           child: Text('Loading....'),
//         );
//       }
//       else{

//         ListView.builder(
//           itemCount: snapshot.data.length,
//           itemBuilder: (_,index){

//             return ListTile(
//             title: Text(snapshot.data[index].data["title"]),
//             );

//         });

//       }

//       },),
      
//     );
//   }
// }
