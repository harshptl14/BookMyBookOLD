import 'package:bookmybook/app_screens/categories.dart';
import 'package:bookmybook/app_screens/initialPages/auth.dart';
import 'package:bookmybook/app_screens/initialPages/login_screen.dart';
import 'package:bookmybook/app_screens/profile.dart';
import 'package:bookmybook/app_screens/selectupload.dart';
import 'package:bookmybook/app_screens/uploadproduct.dart';
import 'package:flutter/material.dart';
import 'package:bookmybook/app_screens/first_screen.dart';

class MyApp extends StatefulWidget {
  MyApp({this.auth, this.onSignedOut});
  final BaseAuth auth;
  final VoidCallback onSignedOut;

  void _signOut() async {
    try {
      await auth.signOut();
      onSignedOut();
    } catch (e) {
      print(e);
    }
  }

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return MyAppState();
  }
}

class MyAppState extends State<MyApp> {
  int _selectedPage = 0;
  final _pageOptions = [
    element(),
    Categories(),
    AddProduct(),
    Text('Item 3'),
    Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        drawer: new Drawer(
          child: FlatButton(
            child: Text(
              'SIGNOUT',
              style: TextStyle(fontSize: 20.0),
            ),
            onPressed: widget._signOut,
          ),
        ),
        body: _pageOptions[_selectedPage],
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white10,
          elevation: 30,
          selectedItemColor: Colors.deepPurple,
          unselectedItemColor: Colors.grey,
          currentIndex: _selectedPage,
          onTap: (int index) {
            setState(() {
              _selectedPage = index;
            });
          },
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              title: Text('Home'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.category),
              title: Text('Categories'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.add_a_photo),
              title: Text('Add'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart),
              title: Text('Cart'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              title: Text('Profile'),
            ),
          ],
        ));
  }
}
