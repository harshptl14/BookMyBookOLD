import 'package:bookmybook/app_screens/initialPages/intro_screen.dart';
import 'package:carousel_pro/carousel_pro.dart' as prefix0;
import 'package:flutter/material.dart';
import 'first_screen.dart';
import 'test.dart';
import 'package:carousel_pro/carousel_pro.dart';

class product extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return thing();
  }
}

class thing extends StatefulWidget {
  @override
  _thingState createState() => _thingState();
}

class _thingState extends State<thing> {
  Icon searchIcon = new Icon(Icons.search);
  Icon bookIcon = new Icon(Icons.bookmark);
  @override
  Widget build(BuildContext context) {
    Widget image_carousel = new Container(
        height: 400.0,
        child: prefix0.Carousel(
          boxFit: BoxFit.scaleDown,
          images: [
            AssetImage('images/nodejsbook.jpeg'),
            AssetImage('images/javabook.png'),
            AssetImage('images/cssbook.jpg'),
          ],
          autoplay: false,
          dotBgColor: Colors.white10,
          dotSize: 5,
          dotIncreasedColor: Colors.black,
          dotColor: Colors.grey,
          dotIncreaseSize: 2,
          animationCurve: Curves.fastOutSlowIn,
          animationDuration: Duration(milliseconds: 1000),
        ));
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            expandedHeight: 400.0,
            floating: false,
            pinned: true,
            snap: false,
            leading: IconButton(color: Colors.black,
            onPressed: (){
              Navigator.push(
                      context, MaterialPageRoute(builder: (context) => element()));
            },
            icon: Icon(Icons.arrow_back),
            ),
            actions: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 16, right: 90),
                child: Text(
                  "BookMyBook",
                  style: TextStyle(
                    fontSize: 22,
                    color: Colors.black,
                    fontFamily: 'Montserrat',
                    fontWeight: FontWeight.bold,

                    // fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              IconButton(
                  icon: searchIcon,
                  color: Colors.black,
                  onPressed: () {
                    heroTag:
                    "search";
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Test()));
                  }),
              IconButton(icon: bookIcon, color: Colors.black, onPressed: () {}),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: new ListView(children: <Widget>[image_carousel]),
            ),
          ),
          SliverFixedExtentList(
              delegate: SliverChildListDelegate([
                Container(
                  alignment: Alignment.center,
                  color: Colors.white,
                  height: 70,
                  margin: EdgeInsets.only(top: 40),
                  child: ListTile(
                    title: Text('C language book',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                          fontFamily: 'Montserrat',
                        )),
                    trailing: Text("₹500",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                          fontFamily: 'Montserrat',
                        )),
                    subtitle: Text("By Prof. Dr. E. Balagurusamy",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: 20),
                  color: Colors.white,
                  height: 200,
                  child: ListTile(
                    title: Text('About',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          fontFamily: 'Montserrat',
                        )),
                    subtitle: Text(
                        "Written by the most well known face of India s IT literacy movement, this book is designed for the first course in C.",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: 20),
                  color: Colors.white,
                  height: 70,
                  child: ListTile(
                    leading: FlutterLogo(size: 56.0),
                    title: Text('Testing User',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          fontFamily: 'Montserrat',
                        )),
                    subtitle: Text('Tap here to know more',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  color: Colors.white,
                  height: 70,
                  child: ListTile(
                    leading: FlutterLogo(size: 56.0),
                    title: Text('Testing User',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          fontFamily: 'Montserrat',
                        )),
                    subtitle: Text('Tap here to know more',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  color: Colors.white,
                  height: 70,
                  child: ListTile(
                    leading: FlutterLogo(size: 56.0),
                    title: Text('Testing User',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          fontFamily: 'Montserrat',
                        )),
                    subtitle: Text('Tap here to know more',
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                  ),
                ),
              ]),
              itemExtent: 150.0)
        ],
      ),
      bottomNavigationBar: Material(
        
        elevation: 15,
        child: Container(
          decoration: BoxDecoration(color: Colors.white),
          height: 55.0,
          width: MediaQuery.of(context).size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
            Container(
              alignment: Alignment.center,
              height: 60,
              width:192.5,
              child: Text(
                'ADD TO BAG',
                style: TextStyle(
                    fontFamily: 'Montserrat',
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold),
              ),
            ),

            Container(
              alignment: Alignment.center,
              height: 60,
              width: 200,
              color: Colors.deepPurple,
              child: Text(
                'BUY NOW',
                style: TextStyle(
                    fontFamily: 'Montserrat',
                    fontSize: 16.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            ),

            

                 
            
          ]),
        ),
      ),
    );
  }
}
