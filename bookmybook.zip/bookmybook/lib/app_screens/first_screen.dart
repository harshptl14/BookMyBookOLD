import 'package:bookmybook/app_screens/test.dart';
import 'recentadd.dart';
import 'package:bookmybook/app_screens/recentadd.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bookmybook/app_screens/initialPages/auth.dart';
import 'home_screen.dart';

class element extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Carousel();
  }
}

class Carousel extends StatefulWidget {
  @override
  _CarouselState createState() => _CarouselState();
}

class _CarouselState extends State<Carousel> {
  Icon searchIcon = new Icon(Icons.search);
  Icon bookIcon = new Icon(Icons.bookmark);
  Icon navigatebarIcon = new Icon(Icons.desktop_windows);
  PageController _pageController;
  int currentPage = 0;
  final imageList = [
    "images/cssbook.jpg",
    "images/mlbook.jpeg",
    "images/phpbook.jpg",
    "images/nodejsbook.jpeg",
    "images/csharbook.png",
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(
      initialPage: currentPage,
      keepPage: false,
      viewportFraction: 0.5,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          appBarTheme: AppBarTheme(
        brightness: Brightness.light,
        elevation: 5,
        color: ThemeData.light().canvasColor,
      )),
      home: Scaffold(
           //drawer: new Drawer(),
        //   child: FlatButton(
        //     child: Text(
        //       'SIGNOUT',
        //       style: TextStyle(fontSize: 20.0),
        //     ),
        //     onPressed: widget._signOut,
        //   ),
        // 
        appBar: AppBar(
          centerTitle: false,
          
          title:
           Text(
            "BookMyBook",
            style: TextStyle(
              fontSize: 22,
              color: Colors.black,
              fontFamily: 'Montserrat',
              fontWeight: FontWeight.bold,
            
              // fontWeight: FontWeight.bold,
            ),
          ),
          iconTheme: new IconThemeData(color: Colors.black),
          actions: <Widget>[
            IconButton(
                icon: searchIcon,
                color: Colors.black,
                onPressed: () {
                  heroTag:
                  "search";
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Test()));
                }),
            IconButton(icon: bookIcon, color: Colors.black, onPressed: () {}),
          ],
          backgroundColor: Colors.white,
        ),
        body: ListView(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(top: 20.0, left: 20.0),
              child: Text(
                "New Books",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Montserrat',
                ),
              ),
            ),
            Column(
              children: <Widget>[
                Center(
                  child: Container(
                    height: 300,
                    child: PageView.builder(
                        itemCount: imageList.length,

                        onPageChanged: (value) {
                          setState(() {
                            currentPage = value;
                          });
                        },
                        controller: _pageController,
                        itemBuilder: (context, index) {
                          return animateItemBuilder(index);
                        }),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 210),
                  child: Text(
                    "Recently Added",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      fontFamily: 'Montserrat',
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Container(
                    height: (product_list.length * 2) * 50.0,
                    child: RecentlyAdd(), 
                    
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  animateItemBuilder(int index) {
    return AnimatedBuilder(
        animation: _pageController,
        builder: (context, child) {
          double value = 1;
          if (_pageController.position.haveDimensions) {
            value = _pageController.page - index;
            value = (1 - (value.abs() * 0.5)).clamp(0.0, 1.0);
          }

          return Center(
            child: SizedBox(

              height: Curves.easeOut.transform(value) * 250,
              width: Curves.easeOut.transform(value) * 250,
              child: child,
            ),
          );
        },
        child: Container(child: Card(
          elevation: 5,

          color: Colors.white,

          child: Image.asset(imageList[index], fit: BoxFit.fill),

        )));
  }
}
